const product={
    {
    id:0;
    image:'burger.jpg';
    title:'Burger';
    price:120;
    };
    {
    
    }

}